(function() {
  'use strict';

  // Applies formatting commands to the text editor content.
  // For example, clicking the H1 button inserts "# " at the beginning of the line;
  // when exported (e.g. as PDF), lines starting with "# " are rendered with a larger font.
  window.applyFormatting = function(format) {
    const textarea = document.getElementById('textEditor');
    if (!textarea) return;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const originalText = textarea.value;
    let modifiedText = originalText;

    switch(format) {
      case 'h1':
        modifiedText = insertAtLineStart(originalText, start, end, '# ');
        break;
      case 'h2':
        modifiedText = insertAtLineStart(originalText, start, end, '## ');
        break;
      case 'h3':
        modifiedText = insertAtLineStart(originalText, start, end, '### ');
        break;
      case 'bold':
        modifiedText = wrapSelection(originalText, start, end, '**');
        break;
      case 'italic':
        modifiedText = wrapSelection(originalText, start, end, '*');
        break;
      case 'ul':
        modifiedText = insertAtLineStart(originalText, start, end, '- ');
        break;
      case 'quote':
        modifiedText = insertAtLineStart(originalText, start, end, '> ');
        break;
      default:
        break;
    }

    textarea.value = modifiedText;
    textarea.focus();
  };

  // Wraps the selected text with the specified wrapper (e.g., ** for bold)
  function wrapSelection(text, start, end, wrapper) {
    const selected = text.substring(start, end);
    return text.substring(0, start) + wrapper + selected + wrapper + text.substring(end);
  }

  // Inserts a prefix at the start of each line in the selected area.
  function insertAtLineStart(text, start, end, prefix) {
    let lineStart = text.lastIndexOf('\n', start - 1);
    lineStart = (lineStart === -1) ? 0 : lineStart + 1;
    let lineEnd = text.indexOf('\n', end);
    lineEnd = (lineEnd === -1) ? text.length : lineEnd;
    const selectedBlock = text.substring(lineStart, lineEnd);
    const lines = selectedBlock.split('\n');
    const formattedLines = lines.map(line => {
      return line.startsWith(prefix) ? line : prefix + line;
    });
    return text.substring(0, lineStart) + formattedLines.join('\n') + text.substring(lineEnd);
  }
})();