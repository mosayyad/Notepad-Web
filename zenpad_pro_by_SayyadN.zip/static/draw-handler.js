class DrawingManager {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { willReadFrequently: true });
    this.undoStack = [];
    this.currentPath = null;
    this.settings = {
      color: '#000000',
      width: 3,
      isEraser: false,
      baseColor: getComputedStyle(canvas).backgroundColor
    };
    this.init();
  }

  init() {
    this.resizeCanvas();
    this.setupInputHandling();
    window.addEventListener('resize', () => this.resizeCanvas());
    
    const savedSettings = localStorage.getItem('drawSettings');
    if (savedSettings) {
      Object.assign(this.settings, JSON.parse(savedSettings));
    }
    this.updateEraserButton();
  }

  updateEraserButton() {
    const eraserBtn = document.getElementById('eraserBtn');
    if (eraserBtn) {
      eraserBtn.classList.toggle('active', this.settings.isEraser);
      eraserBtn.querySelector('svg').style.transform = this.settings.isEraser ? 'rotate(45deg)' : 'none';
    }
  }

  toggleEraser() {
    this.settings.isEraser = !this.settings.isEraser;
    this.settings.color = this.settings.isEraser 
      ? this.settings.baseColor 
      : document.getElementById('drawColor').value;
    this.updateEraserButton();
    localStorage.setItem('drawSettings', JSON.stringify(this.settings));
  }

  setupInputHandling() {
    const getScaledPoint = (clientX, clientY) => {
      const rect = this.canvas.getBoundingClientRect();
      const contentArea = this.canvas.parentElement.parentElement; 
      return {
        x: (clientX - rect.left + contentArea.scrollLeft) / (rect.width / this.canvas.width),
        y: (clientY - rect.top + contentArea.scrollTop) / (rect.height / this.canvas.height)
      };
    };

    const handleStart = (clientX, clientY) => {
      const { x, y } = getScaledPoint(clientX, clientY);
      this.currentPath = {
        points: [{ x, y }],
        color: this.settings.isEraser ? this.settings.baseColor : this.settings.color,
        width: this.settings.width,
        compositeOp: this.settings.isEraser ? 'destination-out' : 'source-over'
      };
      this.undoStack.push(this.currentPath);
    };

    const handleMove = (clientX, clientY) => {
      if (!this.currentPath) return;
      
      const { x, y } = getScaledPoint(clientX, clientY);
      const padding = 100;
      const expand = { left: 0, right: 0, top: 0, bottom: 0 };

      if (x < padding) expand.left = padding - x;
      else if (x > this.canvas.width - padding) 
        expand.right = x - (this.canvas.width - padding);

      if (y < padding) expand.top = padding - y;
      else if (y > this.canvas.height - padding)
        expand.bottom = y - (this.canvas.height - padding);

      if (expand.left + expand.right + expand.top + expand.bottom > 0) {
        this.expandCanvas(expand.left, expand.right, expand.top, expand.bottom);
      }

      this.currentPath.points.push({ x, y });
      this.redraw();
    };

    const handleEnd = () => {
      this.currentPath = null;
    };

    const handleEvent = (e) => {
      if (e.pointerType === 'touch') {
        e.preventDefault();
      }
    };

    this.canvas.addEventListener('pointerdown', e => {
      handleEvent(e);
      handleStart(e.clientX, e.clientY);
    });

    this.canvas.addEventListener('pointermove', e => {
      handleEvent(e);
      handleMove(e.clientX, e.clientY);
    });

    ['pointerup', 'pointercancel'].forEach(event => {
      this.canvas.addEventListener(event, e => {
        handleEvent(e);
        handleEnd();
      });
    });

    this.canvas.addEventListener('contextmenu', e => {
      e.preventDefault();
      this.toggleEraser();
    });
  }

  expandCanvas(left, right, top, bottom) {
    const dpr = window.devicePixelRatio;
    const wrapper = this.canvas.parentElement; 
    const currentCSSWidth = wrapper.clientWidth;
    const currentCSSHeight = wrapper.clientHeight;

    const newCSSWidth = currentCSSWidth + left + right;
    const newCSSHeight = currentCSSHeight + top + bottom;

    if (wrapper) {
      wrapper.style.width = newCSSWidth + 'px';
      wrapper.style.height = newCSSHeight + 'px';
    }

    const scrollContainer = wrapper.parentElement; 
    if (left > 0) scrollContainer.scrollLeft = 0;
    else if (right > 0) scrollContainer.scrollLeft = newCSSWidth - scrollContainer.clientWidth;
    if (top > 0) scrollContainer.scrollTop = 0;
    else if (bottom > 0) scrollContainer.scrollTop = newCSSHeight - scrollContainer.clientHeight;

    const newWidth = newCSSWidth * dpr;
    const newHeight = newCSSHeight * dpr;

    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = newWidth;
    tempCanvas.height = newHeight;
    const tempCtx = tempCanvas.getContext('2d');

    const shiftX = left * dpr;
    const shiftY = top * dpr;
    tempCtx.drawImage(this.canvas, shiftX, shiftY);

    this.canvas.width = newWidth;
    this.canvas.height = newHeight;
    this.ctx.drawImage(tempCanvas, 0, 0);

    if (left > 0 || top > 0) {
      this.undoStack.forEach(path => {
        path.points.forEach(p => {
          p.x += left;
          p.y += top;
        });
      });
    }
    this.redraw();
  }

  redraw() {
    this.ctx.save();
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.ctx.fillStyle = getComputedStyle(this.canvas).backgroundColor;
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    
    this.undoStack.forEach(path => {
      this.ctx.beginPath();
      this.ctx.globalCompositeOperation = path.compositeOp;
      this.ctx.strokeStyle = path.color;
      this.ctx.lineWidth = path.width;
      this.ctx.lineCap = 'round';
      this.ctx.lineJoin = 'round';
      
      path.points.forEach((p, i) => {
        if (i === 0) this.ctx.moveTo(p.x, p.y);
        else this.ctx.lineTo(p.x, p.y);
      });
      this.ctx.stroke();
    });
    this.ctx.restore();
  }

  updateBrushSettings(color, width) {
    this.settings.color = color;
    this.settings.width = width;
    localStorage.setItem('drawSettings', JSON.stringify(this.settings));
  }

  resizeCanvas() {
    const dpr = window.devicePixelRatio || 1;
    const rect = this.canvas.getBoundingClientRect();
    this.canvas.width = rect.width * dpr;
    this.canvas.height = rect.height * dpr;
    this.ctx.scale(dpr, dpr);
    this.redraw();
  }

  getStrokes() {
    return this.undoStack;
  }
  
  clearAll() {
    this.undoStack = [];
    this.redraw();
  }
}

window.DrawingManager = DrawingManager;