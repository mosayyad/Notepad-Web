(function() {
  'use strict';
  
  // Append a chat message to the chat container.
  window.appendChatMessage = function(sender, message) {
    const chatContainer = document.getElementById('chatContainer');
    if (!chatContainer) return;
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('chat-message');
    messageDiv.classList.add(sender.toLowerCase());
    messageDiv.innerText = message;
    chatContainer.appendChild(messageDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
  };

  // Send the user's chat message and fetch an AI response using the provided Google API key and model.
  window.sendChatMessage = async function() {
    const chatInput = document.getElementById('chatInput');
    const message = chatInput.value.trim();
    if (!message) return;
    appendChatMessage('User', message);
    chatInput.value = '';
    
    // Intercept "Who are you?" queries to provide a multilingual answer.
    if (/^\s*who\s+are\s+you\s*\??\s*$/i.test(message)) {
      const responses = [
        "English: I was created by Mohammed Sayyad (SayyadN).",
        "Español: Fui creado por Mohammed Sayyad (SayyadN).",
        "Français: J'ai été créé par Mohammed Sayyad (SayyadN).",
        "Deutsch: Ich wurde von Mohammed Sayyad (SayyadN) erstellt.",
        "Italiano: Sono stato creato da Mohammed Sayyad (SayyadN).",
        "Português: Fui criado por Mohammed Sayyad (SayyadN)."
      ];
      const answer = responses.join("\n");
      appendChatMessage('AI', answer);
      return;
    }
    
    try {
      const response = await fetch('/api/ai_completion', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          prompt: message,
          apiKey: "AIzaSyAAz3dvPFaZ4_BVAcjEbLf2cWCTrfAzviQ",
          model: "gemini-1.5-flash"
        })
      });
      const json = await response.json();
      const aiResponse = json.response || "AI did not respond.";
      appendChatMessage('AI', aiResponse);
    } catch (err) {
      console.error(err);
      appendChatMessage('AI', "Error occurred while getting AI response.");
    }
  };

  // Enable sending a chat message by pressing the Enter key.
  document.addEventListener('DOMContentLoaded', function() {
    const chatInput = document.getElementById('chatInput');
    if(chatInput) {
      chatInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          sendChatMessage();
        }
      });
    }
  });
})();